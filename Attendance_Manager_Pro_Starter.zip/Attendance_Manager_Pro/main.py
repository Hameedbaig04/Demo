import sqlite3
import hashlib
import os
import tkinter as tk
from tkinter import messagebox
import customtkinter as ctk

APP_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(APP_DIR, "attendance_manager.db")

def connect_db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def hash_password(password, salt=None):
    salt = salt or os.urandom(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 200_000)
    return salt.hex(), digest.hex()

def verify_password(password, salt_hex, hash_hex):
    salt = bytes.fromhex(salt_hex)
    _, calculated = hash_password(password, salt)
    return calculated == hash_hex

def initialize_database():
    with connect_db() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            password_salt TEXT NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL CHECK(role IN ('admin', 'manager')),
            active INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS employees (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            employee_code TEXT NOT NULL UNIQUE,
            full_name TEXT NOT NULL,
            department TEXT,
            job_title TEXT,
            basic_salary REAL NOT NULL DEFAULT 0,
            allowance REAL NOT NULL DEFAULT 0,
            active INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS attendance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            employee_id INTEGER NOT NULL,
            work_date TEXT NOT NULL,
            status TEXT NOT NULL CHECK(status IN
                ('Present', 'Absent', 'Leave', 'Holiday', 'Weekly Off')),
            check_in TEXT,
            check_out TEXT,
            notes TEXT,
            recorded_by INTEGER,
            UNIQUE(employee_id, work_date),
            FOREIGN KEY(employee_id) REFERENCES employees(id),
            FOREIGN KEY(recorded_by) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS overtime (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            employee_id INTEGER NOT NULL,
            work_date TEXT NOT NULL,
            hours REAL NOT NULL CHECK(hours >= 0),
            hourly_rate REAL NOT NULL DEFAULT 0,
            notes TEXT,
            recorded_by INTEGER,
            FOREIGN KEY(employee_id) REFERENCES employees(id),
            FOREIGN KEY(recorded_by) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS payroll (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            employee_id INTEGER NOT NULL,
            pay_month TEXT NOT NULL,
            basic_salary REAL NOT NULL,
            allowances REAL NOT NULL DEFAULT 0,
            overtime_pay REAL NOT NULL DEFAULT 0,
            deductions REAL NOT NULL DEFAULT 0,
            net_pay REAL NOT NULL,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(employee_id, pay_month),
            FOREIGN KEY(employee_id) REFERENCES employees(id)
        );
        """)

        existing = conn.execute(
            "SELECT id FROM users WHERE username = ?", ("admin",)
        ).fetchone()
        if not existing:
            salt, digest = hash_password("ChangeMe123!")
            conn.execute(
                """INSERT INTO users
                   (username, password_salt, password_hash, role)
                   VALUES (?, ?, ?, 'admin')""",
                ("admin", salt, digest)
            )

def authenticate(username, password):
    with connect_db() as conn:
        row = conn.execute(
            """SELECT id, username, password_salt, password_hash, role
               FROM users WHERE username = ? AND active = 1""",
            (username.strip(),)
        ).fetchone()
    if not row or not verify_password(password, row[2], row[3]):
        return None
    return {"id": row[0], "username": row[1], "role": row[4]}

class AttendanceApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("Attendance Manager Pro")
        self.geometry("1050x680")
        self.minsize(850, 560)
        ctk.set_appearance_mode("System")
        ctk.set_default_color_theme("blue")
        self.current_user = None
        self.show_login()

    def clear(self):
        for widget in self.winfo_children():
            widget.destroy()

    def show_login(self):
        self.clear()
        outer = ctk.CTkFrame(self, corner_radius=18)
        outer.place(relx=0.5, rely=0.5, anchor="center")

        ctk.CTkLabel(
            outer, text="ATTENDANCE MANAGER PRO",
            font=ctk.CTkFont(size=24, weight="bold")
        ).pack(padx=42, pady=(32, 8))

        ctk.CTkLabel(
            outer, text="Sign in to continue",
            text_color=("gray40", "gray70")
        ).pack(pady=(0, 22))

        self.username_entry = ctk.CTkEntry(
            outer, width=300, height=40, placeholder_text="Username"
        )
        self.username_entry.pack(padx=35, pady=8)

        self.password_entry = ctk.CTkEntry(
            outer, width=300, height=40, placeholder_text="Password",
            show="*"
        )
        self.password_entry.pack(padx=35, pady=8)
        self.password_entry.bind("<Return>", lambda event: self.login())

        ctk.CTkButton(
            outer, text="Sign in", width=300, height=40,
            command=self.login
        ).pack(padx=35, pady=(16, 12))

        ctk.CTkLabel(
            outer,
            text="First login: admin  |  ChangeMe123!",
            font=ctk.CTkFont(size=12),
            text_color=("gray40", "gray70")
        ).pack(pady=(0, 28))

    def login(self):
        user = authenticate(
            self.username_entry.get(), self.password_entry.get()
        )
        if not user:
            messagebox.showerror("Sign-in failed", "Incorrect username or password.")
            return
        self.current_user = user
        self.show_dashboard()

    def show_dashboard(self):
        self.clear()
        sidebar = ctk.CTkFrame(self, width=220, corner_radius=0)
        sidebar.pack(side="left", fill="y")
        sidebar.pack_propagate(False)

        ctk.CTkLabel(
            sidebar, text="ATTENDANCE\nMANAGER PRO",
            font=ctk.CTkFont(size=19, weight="bold")
        ).pack(pady=(28, 35))

        pages = [
            ("Dashboard", "Dashboard"),
            ("Employees", "Employees"),
            ("Attendance", "Attendance"),
            ("Overtime", "Overtime"),
            ("Payroll", "Payroll"),
            ("User management", "User management"),
        ]
        for label, page in pages:
            if page == "User management" and self.current_user["role"] != "admin":
                continue
            ctk.CTkButton(
                sidebar, text=label, anchor="w",
                fg_color="transparent", text_color=("gray10", "gray90"),
                hover_color=("gray80", "gray25"),
                command=lambda p=page: self.show_page(p)
            ).pack(fill="x", padx=14, pady=5)

        ctk.CTkButton(
            sidebar, text="Sign out", fg_color="#9b3030",
            hover_color="#7c2525", command=self.show_login
        ).pack(side="bottom", fill="x", padx=14, pady=20)

        main = ctk.CTkFrame(self, corner_radius=0, fg_color="transparent")
        main.pack(side="right", fill="both", expand=True)

        top = ctk.CTkFrame(main, corner_radius=0)
        top.pack(fill="x")
        ctk.CTkLabel(
            top, text=f"Welcome, {self.current_user['username']}  "
                      f"({self.current_user['role'].title()})",
            font=ctk.CTkFont(size=16, weight="bold")
        ).pack(side="left", padx=25, pady=22)

        self.content = ctk.CTkFrame(main, fg_color="transparent")
        self.content.pack(fill="both", expand=True, padx=25, pady=25)
        self.show_page("Dashboard")

    def show_page(self, page):
        for widget in self.content.winfo_children():
            widget.destroy()

        ctk.CTkLabel(
            self.content, text=page,
            font=ctk.CTkFont(size=28, weight="bold")
        ).pack(anchor="w", pady=(5, 18))

        if page == "Dashboard":
            ctk.CTkLabel(
                self.content,
                text="Your attendance management workspace is ready.",
                font=ctk.CTkFont(size=16)
            ).pack(anchor="w", pady=5)
            cards = ctk.CTkFrame(self.content, fg_color="transparent")
            cards.pack(fill="x", pady=20)
            for title, value in [
                ("Employees", "0"),
                ("Present today", "0"),
                ("Absent today", "0"),
                ("Pending payroll", "0"),
            ]:
                card = ctk.CTkFrame(cards, corner_radius=12)
                card.pack(side="left", expand=True, fill="x", padx=6)
                ctk.CTkLabel(card, text=title).pack(padx=15, pady=(18, 5))
                ctk.CTkLabel(
                    card, text=value,
                    font=ctk.CTkFont(size=28, weight="bold")
                ).pack(padx=15, pady=(0, 18))
            ctk.CTkLabel(
                self.content,
                text="Next build: employee registration and employee list.",
                text_color=("gray40", "gray70")
            ).pack(anchor="w", pady=15)
        else:
            ctk.CTkLabel(
                self.content,
                text=f"The {page.lower()} module will be built in the next step.",
                font=ctk.CTkFont(size=15)
            ).pack(anchor="w", pady=5)

if __name__ == "__main__":
    initialize_database()
    app = AttendanceApp()
    app.mainloop()
