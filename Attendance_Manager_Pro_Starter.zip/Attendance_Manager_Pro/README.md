# Attendance Manager Pro — Starter

## Requirements
- Windows 10
- Python 3.10 or newer

## Setup
1. Install Python from https://www.python.org/downloads/
2. During installation, tick **Add Python to PATH**.
3. Open Command Prompt in this folder.
4. Run:

```bat
py -m pip install -r requirements.txt
py main.py
```

## First login
- Username: `admin`
- Password: `ChangeMe123!`

Change this temporary password before using the app with real employee data.
This starter is a local prototype. It is not yet configured for simultaneous access
from multiple computers. We will build the employee and attendance modules next.
